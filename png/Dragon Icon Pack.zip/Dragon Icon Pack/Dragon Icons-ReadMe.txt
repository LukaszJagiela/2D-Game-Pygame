Credit: Molly "Cougarmint" Willits
Created by hand using Photoshop Educational Edition 6.0 and Pixel Toolbox 1.1.

Licence: CC-BY 3.0.

Free Commercial Use: Yes
Free Personal Use: Yes

Included in this Pack:
Dragonicons.png
Dragonicons2.png
Dragonicons3.png

Icons Folder:
dragon1.ico
dragon2.ico
dragon3.ico
dragon3a.ico
dragon4.ico
dragon5.ico
dragon6.ico
dragon7.ico

Donations: Not needed, but appreciated. Contact me if you'd like to make a donation.